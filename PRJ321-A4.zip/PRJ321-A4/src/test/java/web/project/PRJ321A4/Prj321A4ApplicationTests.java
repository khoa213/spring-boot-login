package web.project.PRJ321A4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Prj321A4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
